var require = meteorInstall({"lib":{"collections":{"enums.js":["meteor/jagi:astronomy",function(require){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// lib/collections/enums.js                                          //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
var _jagiAstronomy = require('meteor/jagi:astronomy');               // 1
///////////////////////////////////////////////////////////////////////

}],"posts.js":["meteor/jagi:astronomy",function(require){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// lib/collections/posts.js                                          //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
var _jagiAstronomy = require('meteor/jagi:astronomy');               // 1
                                                                     //
Posts = new Mongo.Collection('posts');                               // 3
// export const Post = Class.create({                                //
//   name : 'Post',                                                  //
//   collection : Posts,                                             //
//   fields : {                                                      //
//     title : {                                                     //
//       type:String,                                                //
//       validators : [{                                             //
//         type : 'gte',                                             //
//         param : 3,                                                //
//       }],                                                         //
//     },                                                            //
//     userId : String,                                              //
//     publishAt : Date,                                             //
//     craetedAt : Date,                                             //
//   },                                                              //
//   behaviors : {                                                   //
//     timestamp : {}                                                //
//   }                                                               //
// });                                                               //
///////////////////////////////////////////////////////////////////////

}]}},"server":{"publications":{"posts.js":function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// server/publications/posts.js                                      //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
Meteor.publish("posts", function () {                                // 1
  return Posts.find();                                               // 2
});                                                                  //
///////////////////////////////////////////////////////////////////////

}},"seed":{"posts.js":function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// server/seed/posts.js                                              //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
if (_.isEqual(Posts.find().count(), 0)) {                            // 1
  for (var i = 0; i < 25; i++) {                                     // 2
    Posts.insert({                                                   // 3
      name: "Post Test " + [i],                                      // 4
      subbmitedAtt: new Date()                                       // 5
    });                                                              //
  };                                                                 //
};                                                                   //
///////////////////////////////////////////////////////////////////////

}}}},{"extensions":[".js",".json"]});
require("./lib/collections/enums.js");
require("./lib/collections/posts.js");
require("./server/publications/posts.js");
require("./server/seed/posts.js");
//# sourceMappingURL=app.js.map
